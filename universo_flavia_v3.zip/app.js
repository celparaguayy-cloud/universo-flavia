(() => {
  'use strict';
  const C = window.FLAVIA_CONTENT;
  const canvas = document.querySelector('#universe');
  const ctx = canvas.getContext('2d', {alpha:false, desynchronized:true});
  const welcome = document.querySelector('#welcome');
  const enterBtn = document.querySelector('#enterBtn');
  const centerBtn = document.querySelector('#centerBtn');
  const musicBtn = document.querySelector('#musicBtn');
  const helpBtn = document.querySelector('#helpBtn');
  const musicPanel = document.querySelector('#musicPanel');
  const helpPanel = document.querySelector('#helpPanel');
  const musicToggle = document.querySelector('#musicToggle');
  const musicFile = document.querySelector('#musicFile');
  const volume = document.querySelector('#volume');
  const musicName = document.querySelector('#musicName');
  const audio = document.querySelector('#audio');
  const dialog = document.querySelector('#memoryDialog');
  const closeDialog = document.querySelector('#closeDialog');
  const dialogIcon = document.querySelector('#dialogIcon');
  const dialogKicker = document.querySelector('#dialogKicker');
  const dialogTitle = document.querySelector('#dialogTitle');
  const dialogBody = document.querySelector('#dialogBody');
  const dialogPhotos = document.querySelector('#dialogPhotos');
  const dialogFooter = document.querySelector('#dialogFooter');
  const coords = document.querySelector('#coords');
  const discovery = document.querySelector('#discovery');
  const modeLabel = document.querySelector('#modeLabel');
  const regionLabel = document.querySelector('#regionLabel');
  const toast = document.querySelector('#toast');

  const prefersReducedMotion = matchMedia('(prefers-reduced-motion: reduce)').matches;
  const coarse = matchMedia('(pointer: coarse)').matches;
  let W=innerWidth,H=innerHeight,dpr=1;
  let cam={x:0,y:0,zoom:0.08}, target={x:0,y:0,zoom:0.08};
  let time=0, drag=false,moved=false,lastX=0,lastY=0;
  let pinch=null;
  let hoverWorld=null;
  let discovered=new Set(JSON.parse(localStorage.getItem('flavia-discovered-v3')||'[]'));
  let currentObjectUrl='';
  let lastFrame=performance.now();
  let quality=1;
  let firstEntered=false;

  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  const hash=(x,y,n=0)=>{ const s=Math.sin(x*12.9898+y*78.233+n*37.719)*43758.5453; return s-Math.floor(s); };
  const prng=seed=>{let s=(seed>>>0)+0x6D2B79F5;return()=>{s=(s+0x6D2B79F5)|0;let t=Math.imul(s^s>>>15,s|1);t^=t+Math.imul(t^t>>>7,t|61);return((t^t>>>14)>>>0)/4294967296}};
  const worldToScreen=(x,y)=>({x:(x-cam.x)*cam.zoom+W/2,y:(y-cam.y)*cam.zoom+H/2});
  const screenToWorld=(x,y)=>({x:(x-W/2)/cam.zoom+cam.x,y:(y-H/2)/cam.zoom+cam.y});

  function resize(){
    W=innerWidth;H=innerHeight;
    dpr=Math.min(devicePixelRatio||1, coarse?1.5:2);
    canvas.width=Math.floor(W*dpr);canvas.height=Math.floor(H*dpr);canvas.style.width=W+'px';canvas.style.height=H+'px';
    ctx.setTransform(dpr,0,0,dpr,0,0);
  }
  addEventListener('resize',resize,{passive:true});resize();

  function drawBackground(){
    const g=ctx.createRadialGradient(W*.48,H*.48,0,W*.48,H*.48,Math.max(W,H)*.88);
    g.addColorStop(0,'#141a38');g.addColorStop(.35,'#090d21');g.addColorStop(1,'#010208');ctx.fillStyle=g;ctx.fillRect(0,0,W,H);

    ctx.save();ctx.globalCompositeOperation='screen';
    const hazeCount=prefersReducedMotion?4:7;
    for(let i=0;i<hazeCount;i++){
      const wx=(Math.sin(i*2.71)*4100)+(Math.cos(time*.015+i)*180),wy=(Math.cos(i*1.93)*2900);
      const p=worldToScreen(wx,wy);const rr=(700+hash(i,4)*900)*cam.zoom;
      const n=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,Math.max(90,rr));
      n.addColorStop(0,`rgba(${80+i*8},${90+i*8},${220-i*12},${.025+(i%3)*.012})`);n.addColorStop(1,'rgba(0,0,0,0)');
      ctx.fillStyle=n;ctx.beginPath();ctx.arc(p.x,p.y,Math.max(90,rr),0,Math.PI*2);ctx.fill();
    }
    ctx.restore();
  }

  function drawGalaxies(){
    // Infinite tiled galaxy field. Only nearby tiles are generated, so the world has no hard edge.
    const tile=2600;
    const minX=Math.floor((cam.x-W/2/cam.zoom)/tile)-1,maxX=Math.ceil((cam.x+W/2/cam.zoom)/tile)+1;
    const minY=Math.floor((cam.y-H/2/cam.zoom)/tile)-1,maxY=Math.ceil((cam.y+H/2/cam.zoom)/tile)+1;
    const maxTiles=quality>.7?64:36;let count=0;
    for(let gx=minX;gx<=maxX;gx++)for(let gy=minY;gy<=maxY;gy++){
      if(count++>maxTiles)break;
      const r=prng(((gx*92837111)^(gy*689287499))>>>0);
      const chance=r();
      if(chance<.50)continue;
      const wx=gx*tile+(r()-.5)*1200,wy=gy*tile+(r()-.5)*1200;
      const p=worldToScreen(wx,wy);if(p.x<-700||p.x>W+700||p.y<-700||p.y>H+700)continue;
      const arms=3+Math.floor(r()*3),size=(210+r()*260)*cam.zoom;
      const grad=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,Math.max(25,size));
      grad.addColorStop(0,'rgba(255,220,120,.15)');grad.addColorStop(.18,'rgba(170,180,255,.08)');grad.addColorStop(1,'rgba(0,0,0,0)');
      ctx.fillStyle=grad;ctx.beginPath();ctx.arc(p.x,p.y,Math.max(25,size),0,Math.PI*2);ctx.fill();
      if(cam.zoom<.12){
        ctx.save();ctx.translate(p.x,p.y);ctx.rotate(r()*6.28);ctx.strokeStyle='rgba(255,225,130,.10)';ctx.lineWidth=Math.max(1,2*cam.zoom); 
        for(let a=0;a<arms;a++){
          ctx.beginPath();for(let t=0;t<1;t+=.035){const a2=a*6.28/arms+t*5.2,rr=t*size;const sx=Math.cos(a2)*rr,sy=Math.sin(a2)*rr*.6; if(t===0)ctx.moveTo(sx,sy);else ctx.lineTo(sx,sy);}ctx.stroke();
        }
        ctx.restore();
      }
    }
  }

  function drawStars(){
    const tile=1500,minX=Math.floor((cam.x-W/2/cam.zoom)/tile)-1,maxX=Math.ceil((cam.x+W/2/cam.zoom)/tile)+1,minY=Math.floor((cam.y-H/2/cam.zoom)/tile)-1,maxY=Math.ceil((cam.y+H/2/cam.zoom)/tile)+1;
    const budget=prefersReducedMotion?700:Math.round(quality*1500);let drawn=0;
    for(let gx=minX;gx<=maxX;gx++)for(let gy=minY;gy<=maxY;gy++){
      const r=prng(((gx*73856093)^(gy*19349663))>>>0);const n=Math.floor(18+r()*65);
      for(let i=0;i<n;i++){
        if(drawn++>budget)break;
        const wx=gx*tile+(r()-.5)*tile,wy=gy*tile+(r()-.5)*tile,p=worldToScreen(wx,wy);
        if(p.x<-3||p.x>W+3||p.y<-3||p.y>H+3)continue;
        const tw=prefersReducedMotion?1:.64+.36*Math.sin(time*(.8+r()*1.8)+r()*6.28);
        ctx.fillStyle=`rgba(246,247,255,${(.12+r()*.7)*tw})`;ctx.beginPath();ctx.arc(p.x,p.y,(.25+r()*1.35)*Math.max(.65,Math.min(1.4,cam.zoom)),0,Math.PI*2);ctx.fill();
      }
    }
  }

  function systemKey(x,y){return `${Math.round(x/170)}:${Math.round(y/170)}`;}
  function drawProceduralSystems(){
    if(cam.zoom<.13)return;
    const tile=900,minX=Math.floor((cam.x-W/2/cam.zoom)/tile)-1,maxX=Math.ceil((cam.x+W/2/cam.zoom)/tile)+1,minY=Math.floor((cam.y-H/2/cam.zoom)/tile)-1,maxY=Math.ceil((cam.y+H/2/cam.zoom)/tile)+1;
    for(let gx=minX;gx<=maxX;gx++)for(let gy=minY;gy<=maxY;gy++){
      const r=prng(((gx*492876847)^(gy*934857001))>>>0);if(r()<.45)continue;
      const wx=gx*tile+(r()-.5)*600,wy=gy*tile+(r()-.5)*600,p=worldToScreen(wx,wy);if(p.x<-150||p.x>W+150||p.y<-150||p.y>H+150)continue;
      const star=4+7*r()*Math.min(1.3,cam.zoom*4);ctx.fillStyle='rgba(255,230,145,.34)';ctx.beginPath();ctx.arc(p.x,p.y,star,0,Math.PI*2);ctx.fill();
      if(cam.zoom>.24){
        const orbits=2+Math.floor(r()*3);ctx.strokeStyle='rgba(255,224,130,.055)';ctx.lineWidth=1;
        for(let i=1;i<=orbits;i++){const rr=(45+i*28)*cam.zoom;ctx.beginPath();ctx.ellipse(p.x,p.y,rr,rr*.58,0,0,Math.PI*2);ctx.stroke();const a=time*(.14/i)+i;ctx.fillStyle='rgba(180,190,230,.48)';ctx.beginPath();ctx.arc(p.x+Math.cos(a)*rr,p.y+Math.sin(a)*rr*.58,1.6+i*.45,0,Math.PI*2);ctx.fill();}
      }
    }
  }

  function drawFlowers(){
    if(cam.zoom<.15)return;
    const cell=260,minX=Math.floor((cam.x-W/2/cam.zoom)/cell)-1,maxX=Math.ceil((cam.x+W/2/cam.zoom)/cell)+1,minY=Math.floor((cam.y-H/2/cam.zoom)/cell)-1,maxY=Math.ceil((cam.y+H/2/cam.zoom)/cell)+1;
    let budget=prefersReducedMotion?80:210;
    for(let gx=minX;gx<=maxX;gx++)for(let gy=minY;gy<=maxY;gy++){
      if(budget--<=0)return;const r=prng(((gx*141650963)^(gy*325333559))>>>0);if(r()<.58)continue;
      const wx=gx*cell+(r()-.5)*200,wy=gy*cell+(r()-.5)*200,p=worldToScreen(wx,wy);if(p.x<-25||p.x>W+25||p.y<-25||p.y>H+25)continue;
      const alpha=.10+r()*.24;ctx.globalAlpha=alpha;ctx.font=`${7+r()*8}px serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.fillText('🌻',p.x,p.y);ctx.globalAlpha=1;
    }
  }

  function drawConstellation(){
    if(cam.zoom>.75)return;const c=worldToScreen(0,0);ctx.strokeStyle='rgba(255,227,130,.07)';ctx.lineWidth=1;
    for(const m of C.memoryWorlds.slice(1)){const p=worldToScreen(m.x,m.y);ctx.beginPath();ctx.moveTo(c.x,c.y);ctx.lineTo(p.x,p.y);ctx.stroke();}
  }

  function drawWorld(m){
    if(cam.zoom<.075 && m.id!=='center') return;
    const p=worldToScreen(m.x,m.y);const radius=Math.max(7,m.r*cam.zoom*.43);if(p.x<-radius*3||p.x>W+radius*3||p.y<-radius*3||p.y>H+radius*3)return;
    const gl=ctx.createRadialGradient(p.x,p.y,0,p.x,p.y,Math.max(40,radius*3));gl.addColorStop(0,'rgba(255,218,90,.22)');gl.addColorStop(1,'rgba(255,218,90,0)');ctx.fillStyle=gl;ctx.beginPath();ctx.arc(p.x,p.y,Math.max(40,radius*3),0,Math.PI*2);ctx.fill();
    ctx.save();ctx.translate(p.x,p.y);
    if(m.id==='center'){ctx.rotate(time*.035);ctx.strokeStyle='rgba(255,226,120,.22)';ctx.lineWidth=1.5;ctx.setLineDash([6,9]);ctx.beginPath();ctx.ellipse(0,0,radius*1.7,radius*.65,0,0,Math.PI*2);ctx.stroke();ctx.rotate(Math.PI/2);ctx.beginPath();ctx.ellipse(0,0,radius*1.5,radius*.52,0,0,Math.PI*2);ctx.stroke();ctx.setLineDash([]);}
    const grad=ctx.createRadialGradient(-radius*.28,-radius*.32,radius*.06,0,0,radius);grad.addColorStop(0,'#fff5ae');grad.addColorStop(.14,'#f7db65');grad.addColorStop(.55,m.id==='center'?'#8f6c2a':'#303a66');grad.addColorStop(1,'#050818');ctx.fillStyle=grad;ctx.beginPath();ctx.arc(0,0,radius,0,Math.PI*2);ctx.fill();ctx.strokeStyle='rgba(255,224,112,.67)';ctx.lineWidth=1.2;ctx.stroke();
    if(m.id!=='center'){ctx.rotate(-.2);ctx.strokeStyle='rgba(255,226,125,.17)';ctx.beginPath();ctx.ellipse(0,0,radius*1.5,radius*.38,0,0,Math.PI*2);ctx.stroke();}
    ctx.restore();
    ctx.textAlign='center';ctx.textBaseline='middle';ctx.font=`${Math.max(12,Math.min(34,radius*.75))}px serif`;ctx.fillStyle='#fff';ctx.fillText(m.icon,p.x,p.y);
    if(cam.zoom>.085){ctx.font=`700 ${Math.max(9,Math.min(13,12*cam.zoom))}px system-ui`;ctx.fillStyle='rgba(255,255,255,.78)';ctx.fillText(m.title,p.x,p.y+radius+15);}
    if(cam.zoom>.18){const flowers=m.id==='center'?7:2;for(let i=0;i<flowers;i++){const a=time*.11+i*6.283/flowers,rr=radius*(1.25+i*.13);ctx.font=`${Math.max(8,Math.min(16,radius*.34))}px serif`;ctx.globalAlpha=.52;ctx.fillText('🌻',p.x+Math.cos(a)*rr,p.y+Math.sin(a)*rr*.58);ctx.globalAlpha=1;}}
  }

  function drawDeepSystem(m){
    if(cam.zoom<.78)return;const p=worldToScreen(m.x,m.y);if(p.x<-600||p.x>W+600||p.y<-600||p.y>H+600)return;
    const scale=Math.min(1.8,cam.zoom);ctx.save();
    for(let i=1;i<=7;i++){const rx=(48+i*38)*scale,ry=rx*.56;ctx.strokeStyle=`rgba(255,225,132,${.085-i*.007})`;ctx.beginPath();ctx.ellipse(p.x,p.y,rx,ry,0,0,Math.PI*2);ctx.stroke();const a=time*(.17/i)+i;ctx.fillStyle=i%3===0?'#f4d766':'#abb2d9';ctx.beginPath();ctx.arc(p.x+Math.cos(a)*rx,p.y+Math.sin(a)*ry,2+i*.45,0,Math.PI*2);ctx.fill();}
    ctx.restore();
  }

  function currentMode(){
    if(cam.zoom<.105)return ['MAPA GALÁCTICO','Muy lejos'];
    if(cam.zoom<.21)return ['CÚMULOS Y NEBULOSAS','Exploración profunda'];
    if(cam.zoom<.52)return ['SISTEMAS ESTELARES','Entre recuerdos y estrellas'];
    if(cam.zoom<1.05)return ['MUNDOS DE LA HISTORIA','Descubrí un mundo'];
    return ['SISTEMA ORBITAL','Estás muy cerca'];
  }

  function nearestRegion(){
    const regions=[
      {x:-200,y:-80,r:2100,n:'La Nebulosa de las Flores Amarillas'},
      {x:-1250,y:600,r:1650,n:'La Vía de los Recuerdos'},
      {x:2100,y:-700,r:1900,n:'La Frontera del Futuro'},
      {x:0,y:0,r:1200,n:'El Corazón del Universo'}
    ];let best=regions[3],d=Infinity;for(const rg of regions){const dd=Math.hypot(cam.x-rg.x,cam.y-rg.y);if(dd<d){d=dd;best=rg;}}return best;
  }

  function updateHud(){
    const [a,b]=currentMode();modeLabel.textContent=a;regionLabel.textContent=nearestRegion().n+' · '+b;coords.textContent=`X ${Math.round(cam.x)} · Y ${Math.round(cam.y)} · Z ${cam.zoom.toFixed(2)}`;
    discovery.textContent=`${discovered.size} mundos descubiertos`;
  }

  function toastMessage(msg){toast.textContent=msg;toast.classList.add('show');clearTimeout(toastMessage.t);toastMessage.t=setTimeout(()=>toast.classList.remove('show'),2400);}

  function frame(now){
    const dt=Math.min(34,now-lastFrame);lastFrame=now;time+=dt*.0008;
    const smoothing=prefersReducedMotion?.22:.11;cam.x+=(target.x-cam.x)*smoothing;cam.y+=(target.y-cam.y)*smoothing;cam.zoom+=(target.zoom-cam.zoom)*smoothing;
    drawBackground();drawGalaxies();drawStars();drawProceduralSystems();drawFlowers();drawConstellation();for(const m of C.memoryWorlds)drawWorld(m);for(const m of C.memoryWorlds)drawDeepSystem(m);updateHud();requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);

  function markDiscovered(m){if(!discovered.has(m.id)){discovered.add(m.id);localStorage.setItem('flavia-discovered-v3',JSON.stringify([...discovered]));toastMessage(`Descubriste: ${m.title}`);}}
  function hitTest(sx,sy){const w=screenToWorld(sx,sy);let best=null,bestD=Infinity;for(const m of C.memoryWorlds){const d=Math.hypot(w.x-m.x,w.y-m.y);const hit=m.r*.45+45/cam.zoom;if(d<hit&&d<bestD){best=m;bestD=d;}}return best;}
  function openMemory(m){markDiscovered(m);dialogIcon.textContent=m.icon;dialogKicker.textContent=m.kicker;dialogTitle.textContent=m.title;dialogBody.textContent=m.body;dialogPhotos.innerHTML=m.photos?'<div class="photo-card">📷<span>Tu foto aquí</span></div><div class="photo-card">📷<span>Tu foto aquí</span></div><div class="photo-card">📷<span>Tu foto aquí</span></div>':'';dialogFooter.textContent=m.id==='future'?'Este mundo está reservado para lo que todavía no existe. La historia continúa.':'Seguí viajando. El universo no termina en esta coordenada.';dialog.showModal();}

  canvas.addEventListener('pointerdown',e=>{canvas.setPointerCapture(e.pointerId);drag=true;moved=false;lastX=e.clientX;lastY=e.clientY;});
  canvas.addEventListener('pointermove',e=>{const dx=e.clientX-lastX,dy=e.clientY-lastY;if(drag){if(Math.abs(dx)+Math.abs(dy)>4)moved=true;target.x-=dx/target.zoom;target.y-=dy/target.zoom;lastX=e.clientX;lastY=e.clientY;}else{hoverWorld=screenToWorld(e.clientX,e.clientY);}});
  canvas.addEventListener('pointerup',e=>{drag=false;if(!moved){const m=hitTest(e.clientX,e.clientY);if(m)openMemory(m);}});
  canvas.addEventListener('pointercancel',()=>{drag=false});
  canvas.addEventListener('wheel',e=>{e.preventDefault();const before=screenToWorld(e.clientX,e.clientY);const next=clamp(target.zoom*Math.exp(-e.deltaY*.001),.035,3.6);target.zoom=next;const after=screenToWorld(e.clientX,e.clientY);target.x+=before.x-after.x;target.y+=before.y-after.y;},{passive:false});

  function touchPoint(a,b){return{x:(a.clientX+b.clientX)/2,y:(a.clientY+b.clientY)/2,d:Math.hypot(a.clientX-b.clientX,a.clientY-b.clientY)}}
  addEventListener('touchstart',e=>{if(e.touches.length===2){const p=touchPoint(e.touches[0],e.touches[1]);pinch={d:p.d,mid:p,zoom:target.zoom,x:target.x,y:target.y,world:screenToWorld(p.x,p.y)};}},{passive:true});
  addEventListener('touchmove',e=>{if(e.touches.length!==2||!pinch)return;const p=touchPoint(e.touches[0],e.touches[1]);target.zoom=clamp(pinch.zoom*(p.d/pinch.d),.035,3.6);const after=screenToWorld(p.x,p.y);target.x+=pinch.world.x-after.x;target.y+=pinch.world.y-after.y;},{passive:true});
  addEventListener('touchend',()=>{pinch=null},{passive:true});

  enterBtn.addEventListener('click',()=>{welcome.classList.add('hidden');firstEntered=true;toastMessage('Explorá sin apuro. No hay un final.');});
  centerBtn.addEventListener('click',()=>{target.x=0;target.y=0;target.zoom=.21;});
  helpBtn.addEventListener('click',()=>{helpPanel.classList.toggle('hidden');musicPanel.classList.add('hidden');});
  musicBtn.addEventListener('click',()=>{musicPanel.classList.toggle('hidden');helpPanel.classList.add('hidden');});
  closeDialog.addEventListener('click',()=>dialog.close());
  dialog.addEventListener('click',e=>{if(e.target===dialog)dialog.close();});

  musicFile.addEventListener('change',e=>{
    const file=e.target.files?.[0];if(!file)return;if(currentObjectUrl)URL.revokeObjectURL(currentObjectUrl);currentObjectUrl=URL.createObjectURL(file);audio.src=currentObjectUrl;audio.volume=Number(volume.value);musicName.textContent=file.name;toastMessage('Audio cargado.');
  });
  musicToggle.addEventListener('click',async()=>{if(!audio.src){toastMessage('Primero cargá una canción.');return;}try{if(audio.paused){await audio.play();musicToggle.textContent='Pausar';}else{audio.pause();musicToggle.textContent='Reproducir';}}catch{toastMessage('El navegador bloqueó la reproducción hasta una interacción.');}});
  volume.addEventListener('input',()=>{audio.volume=Number(volume.value);});

  // Lightweight adaptive quality: if frames stay slow, reduce procedural density.
  setInterval(()=>{const fps=1000/Math.max(16,performance.now()-lastFrame);if(fps<38)quality=.62;else if(fps>53)quality=Math.min(1,quality+.08);},1800);
})();
