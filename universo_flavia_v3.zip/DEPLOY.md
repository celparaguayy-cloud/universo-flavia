# Publicación web

## En tu GitHub Pages existente

Copiá el contenido de esta carpeta dentro de una carpeta llamada `universo-flavia/` del repositorio que ya publica tu GitHub Pages.

La URL prevista será:

`https://celparaguayy-cloud.github.io/nande-hacklab/universo-flavia/`

## Recomendación

No subas todavía canciones comerciales al repositorio. Usá audio propio/licenciado o una integración autorizada. El reproductor V3 ya permite cargar una pista local para pruebas.
