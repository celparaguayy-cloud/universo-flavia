window.FLAVIA_CONTENT = Object.freeze({
  title: 'El Universo de Flavia',
  date: '25 de febrero de 2024',
  memoryWorlds: [
    {id:'center', x:0, y:0, r:290, icon:'🌻', tier:0, kicker:'EL CORAZÓN', title:'Nuestra historia', body:'Este es el centro de todo. Acá vive la historia completa: cómo empezó, lo que vivimos, las cartas, las fotos, los abrazos, nuestras fechas y todo lo que todavía nos queda por vivir.'},
    {id:'start', x:-1050, y:-620, r:135, icon:'📱', tier:1, kicker:'CAPÍTULO I', title:'Donde empezó todo', body:'Instagram fue el primer puente. Una conversación que abrió una puerta y terminó convirtiéndose en parte de nuestra historia.'},
    {id:'distance', x:820, y:-820, r:145, icon:'💫', tier:1, kicker:'CAPÍTULO II', title:'Cuando existía la distancia', body:'Antes de compartir el mismo espacio, aprendimos a compartir palabras, tiempo, paciencia y ganas. Este sistema guarda aquella etapa.'},
    {id:'hug', x:-780, y:760, r:150, icon:'🤍', tier:1, kicker:'CAPÍTULO III', title:'El primer abrazo', body:'Hay recuerdos que no necesitan muchas palabras. Este planeta existe para conservar el primer encuentro y ese abrazo que hizo real todo lo anterior.'},
    {id:'violet', x:980, y:700, r:125, icon:'🌷', tier:1, kicker:'UN DETALLE', title:'La rosa violeta', body:'Una rosa violeta se convirtió en un detalle inolvidable. Un objeto pequeño puede guardar un recuerdo enorme.'},
    {id:'letters', x:-1700, y:-220, r:120, icon:'💌', tier:1, kicker:'ARCHIVO DE PALABRAS', title:'Las cartas', body:'Este mundo queda reservado para cartas, notas y mensajes. Cada nueva carta puede convertirse en otro planeta o satélite.'},
    {id:'book', x:1580, y:-130, r:112, icon:'📖', tier:1, kicker:'96 PÁGINAS', title:'El cuaderno', body:'Un cuaderno de 96 páginas de notas y recuerdos. Esta zona está pensada para convertirse en una constelación de páginas.'},
    {id:'photos', x:-1450, y:1190, r:135, icon:'📸', tier:1, kicker:'ARCHIVO VISUAL', title:'Nuestro álbum', body:'Cada foto puede convertirse en un planeta con fecha, contexto y un pequeño texto sobre lo que estaba pasando en ese momento.', photos:true},
    {id:'flavia', x:1390, y:1190, r:160, icon:'🌻', tier:1, kicker:'ELLA', title:'Flavia', body:'Una galaxia dedicada a ella: sus detalles, cualidades, frases, gestos y pequeñas cosas que querés conservar. Esta zona puede crecer indefinidamente.'},
    {id:'date', x:2380, y:310, r:110, icon:'❤️', tier:1, kicker:'COORDENADA ESPECIAL', title:'25 de febrero de 2024', body:'25 de febrero de 2024. Una fecha guardada como una coordenada permanente en el mapa de nuestra historia.'},
    {id:'present', x:-2470, y:-1060, r:125, icon:'🎓', tier:1, kicker:'EL PRESENTE', title:'Un nuevo capítulo', body:'El presente también merece un lugar. Acá pueden vivir nuevas etapas, logros y momentos que algún día se convertirán en recuerdos.'},
    {id:'future', x:2920, y:-1120, r:170, icon:'♾️', tier:1, kicker:'SIN FINAL', title:'Lo que todavía no vivimos', body:'Este mundo está incompleto a propósito. Sus lugares esperan historias que todavía no existen. Por eso este universo nunca tiene un final.'}
  ]
});
