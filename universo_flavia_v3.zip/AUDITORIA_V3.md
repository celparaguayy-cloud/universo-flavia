# Auditoría y reconstrucción — Universo de Flavia V3

## Problemas detectados en V2

1. **Sensación de universo insuficiente.** Había navegación, pero el escenario se comportaba principalmente como un mapa con mundos fijos. V3 separa niveles: galaxias → cúmulos/nebulosas → sistemas estelares → mundos narrativos → órbitas.
2. **Error de runtime.** La versión anterior tenía una referencia a una variable `t` inexistente en la decoración de flores. V3 elimina esa referencia y usa un reloj único `time`.
3. **Escala limitada.** Los mundos principales estaban definidos, pero el espacio lejano no tenía una verdadera estrategia de generación por coordenadas. V3 usa generación determinista por tiles alrededor de la cámara; alejarse descubre nuevo espacio sin almacenar millones de objetos.
4. **Pinch incompleto.** V3 ancla el zoom al punto medio de los dedos para que el universo no “salte” durante el gesto.
5. **Música ficticia.** V2 simulaba un botón con un `alert`. V3 añade un reproductor real y carga de audio local, sin empaquetar música comercial no autorizada.
6. **Contenido y lógica mezclados.** V3 separa `content.js`, lo que permitirá reemplazar textos, fechas, fotos y capítulos sin tocar el motor.
7. **Falta de persistencia narrativa.** V3 guarda descubrimientos en `localStorage`, manteniendo el progreso en el dispositivo.
8. **Rendimiento.** V3 limita el número de objetos por nivel, usa `desynchronized` cuando está disponible y adapta la densidad procedural si los frames bajan.
9. **Accesibilidad y reducción de movimiento.** V3 incorpora etiquetas, roles, controles claros y respeta `prefers-reduced-motion`.
10. **PWA base.** Se añade `manifest.webmanifest` para dejar el proyecto listo para convertirse en PWA.

## Auditoría estática ejecutada

- `node --check app.js` → debe pasar sin errores de sintaxis.
- La versión V3 no depende de librerías externas.
- No contiene llamadas a APIs remotas ni claves.
- La música se maneja como archivo del usuario o como asset que el propietario tenga derecho a distribuir.

## Próximas mejoras profundas

- Editor visual para añadir recuerdos y cartas sin editar código.
- Constelaciones narrativas con fechas reales.
- Galaxias con identidad propia y transiciones de nivel más suaves.
- Sistema de capítulos con fotos reales y texto progresivo.
- Soporte de audio por regiones, con crossfade.
- PWA offline completa con Service Worker.
- Modo cinematográfico para la apertura y momentos especiales.
- Sistema de “memorias futuras” que pueda crecer durante años.
