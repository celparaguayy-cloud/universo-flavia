# El Universo de Flavia V3 🌻🌌

Universo 2D navegable, procedural y sin borde visible.

## Navegación

- Arrastrar → viajar.
- Rueda → zoom centrado en el cursor.
- Pellizcar → zoom centrado en el gesto.
- Tocar/click → abrir un mundo de historia.
- Centro → regresar al corazón.

## Escalas

A gran distancia aparecen galaxias y cúmulos. Al acercarse aparecen sistemas estelares; después mundos narrativos y, con más zoom, sus órbitas.

## Contenido

Los recuerdos reales están separados en `content.js` para facilitar la edición.

## Música

El reproductor permite cargar audio desde el dispositivo. Para una publicación pública, usá únicamente audio propio, con licencia o incorporado mediante una integración autorizada.
